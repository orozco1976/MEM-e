# Estimador de Costo de Energía - GDMTH vs MEM

Esta aplicación web permite estimar el costo mensual de energía eléctrica para usuarios bajo la tarifa **GDMTH** de CFE y compararlo con precios del **Mercado Eléctrico Mayorista (MEM)** utilizando datos del **CENACE**.

## ⚙️ Características

- Selección de nodo CENACE (Puebla, CDMX, Guadalajara, Monterrey)
- Cálculo de costos con tarifa GDMTH y MEM
- Gráfica interactiva de evolución del PML (Precio Marginal Local)
- Informe descargable en formato CSV

## 🚀 Cómo usar en GitHub Pages

1. Clona este repositorio o súbelo directamente a GitHub.
2. Ve a **Settings > Pages** en el repositorio.
3. En la sección **"Source"**, selecciona:
   - Rama: `main`
   - Carpeta: `/ (root)`
4. Guarda y GitHub generará una URL pública como:
   ```
   https://<tu-usuario>.github.io/<nombre-del-repo>/
   ```

## 🧪 Notas

- Para funcionamiento en pruebas, utiliza el siguiente proxy:
  - `https://cors-anywhere.herokuapp.com/corsdemo` (haz clic en "Request temporary access")
- Este proxy se usa para evitar errores de CORS al consultar servicios de CENACE y CFE.

## 📁 Archivos principales

- `index.html`: interfaz principal con la lógica JavaScript
- `README.md`: este archivo con instrucciones

---

Desarrollado con ❤️ para análisis energético en México.
